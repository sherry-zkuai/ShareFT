node --version: v15.1.0
npm --version: 7.0.8

第一次运行前，在demo文件夹中，运行'npm install'安装dependency

在demo文件夹中，运行start文件，确保node和npm的正确版本已安装
